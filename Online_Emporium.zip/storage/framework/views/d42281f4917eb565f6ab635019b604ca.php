
<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Sản phẩm làm đẹp da</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            <div class="section" id="info-cart-wp">
                <div class="section-detail table-responsive">
                    <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <table class="table" style="min-height: 370px;">
                            <thead>
                                <tr>
                                    <td>Mã sản phẩm</td>
                                    <td>Ảnh sản phẩm</td>
                                    <td>Tên sản phẩm</td>
                                    <td>Giá sản phẩm</td>
                                    <td>Số lượng</td>
                                    <td colspan="2">Thành tiền</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($item->options->code_product); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('product.detail', [Str::slug($item->name), $item->id])); ?>" title="" class="thumb">
                                                <img src="<?php echo e(url($item->options->file)); ?>" alt="">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="" title="" class="name-product"><?php echo e($item->name); ?></a>
                                        </td>
                                        <td><?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</td>
                                        <td>
                                            <input type="number" id="<?php echo e($item->rowId); ?>" data-price="<?php echo e($item->price); ?>" data-rowId="<?php echo e($item->rowId); ?>" name="num-order"
                                                min="1" max="20" value="<?php echo e($item->qty); ?>" class="num-order">
                                        </td>
                                        <td id="subtotal<?php echo e($item->rowId); ?>"><?php echo e(number_format($item->qty * $item->price, 0, ',', '.')); ?>đ</td>
                                        <td>
                                            <a href="<?php echo e(route('cart.delete', $item->rowId)); ?>" title=""
                                                class="del-product"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-danger">Không tồn tại sản phẩm nào, click <a
                                                href="<?php echo e(route('product.show')); ?>">Vào đây</a> để mua hàng</td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                            <?php if(Cart::count() > 0): ?>
                            <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <div class="clearfix">
                                            <p id="total-price" class="fl-right">Tổng giá:
                                                <span id="total_many"><?php echo e(Cart::subtotal()); ?>đ</span></p>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7">
                                        <div class="clearfix">
                                            <div class="fl-right">
                                                
                                                <a href="<?php echo e(route('checkout')); ?>" title="" id="checkout-cart">Thanh toán</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </form>
                </div>
            </div>
            <div class="section" id="action-cart-wp">
                <div class="section-detail">
                    <p class="title"> Thay đổi số lượng sản phẩm tại số lượng. Nhấn vào thanh toán để mua hàng.</p>
                    <a href="<?php echo e(route('product.show')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                    <a href="<?php echo e(route('cart.destroy')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/client/cart/show.blade.php ENDPATH**/ ?>