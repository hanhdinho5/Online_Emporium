
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="home-page clearfix">
        <div class="wp-inner">
            <div class="main-content fl-right">
                <div class="section" id="slider-wp">
                    <div class="section-detail">
                        <div class="item">
                            <img src="<?php echo e(asset('client.css/images/slider-01.png')); ?>" alt="">
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('client.css/images/slider-02.png')); ?>" alt="">
                        </div>
                        <div class="item">
                            <img src="<?php echo e(asset('client.css/images/slider-03.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
                <div class="section" id="support-wp">
                    <div class="section-detail">
                        <ul class="list-item clearfix">
                            <li>
                                <div class="thumb">
                                    <img src="<?php echo e(asset('client.css/images/icon-1.png')); ?>">
                                </div>
                                <h3 class="title">Miễn phí vận chuyển</h3>
                                <p class="desc">Tới tận tay khách hàng</p>
                            </li>
                            <li>
                                <div class="thumb">
                                    <img src="<?php echo e(asset('client.css/images/icon-2.png')); ?>">
                                </div>
                                <h3 class="title">Tư vấn 24/7</h3>
                                <p class="desc">1900.9999</p>
                            </li>
                            <li>
                                <div class="thumb">
                                    <img src="<?php echo e(asset('client.css/images/icon-3.png')); ?>">
                                </div>
                                <h3 class="title">Tiết kiệm hơn</h3>
                                <p class="desc">Với nhiều ưu đãi cực lớn</p>
                            </li>
                            <li>
                                <div class="thumb">
                                    <img src="<?php echo e(asset('client.css/images/icon-4.png')); ?>">
                                </div>
                                <h3 class="title">Thanh toán nhanh</h3>
                                <p class="desc">Hỗ trợ nhiều hình thức</p>
                            </li>
                            <li>
                                <div class="thumb">
                                    <img src="<?php echo e(asset('client.css/images/icon-4.png')); ?>">
                                </div>
                                <h3 class="title">Đặt hàng online</h3>
                                <p class="desc">Thao tác đơn giản</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="section" id="feature-product-wp">
                    <div class="section-head">
                        <h3 class="section-title">Sản phẩm nổi bật</h3>
                    </div>
                    <div class="section-detail">
                        <ul class="list-item">
                            <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <a href="<?php echo e(route('product.detail', [$featuredProduct->slug, $featuredProduct->id])); ?>"
                                        title="" class="thumb">
                                        <img src="<?php echo e(url($featuredProduct->img)); ?>">
                                    </a>
                                    <a href="?page=detail_product" title=""
                                        class="product-name"><?php echo e($featuredProduct->name); ?></a>
                                    <div class="price">
                                        <span
                                            class="new"><?php echo e(number_format($featuredProduct->price, 0, ',', '.')); ?>đ</span>
                                        <span class="old">22.190.000đ</span>
                                    </div>
                                    <div class="action clearfix">
                                        <a href="" data-id="<?php echo e($featuredProduct->id); ?>"
                                            class="add-cart fl-left add_product">Thêm giỏ hàng</a>
                                        <a href="<?php echo e(route('checkout_fast', $featuredProduct->id)); ?>" title=""
                                            class="buy-now fl-right">Mua ngay</a>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-danger">Không có sản phẩm nổi bậc nào</p>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $list_cat_pr0; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($item_cat->products->count() > 0): ?>
                        <div class="section" id="list-product-wp">
                            <div class="section-head">
                                <h3 class="section-title"><?php echo e($item_cat->name); ?></h3>
                            </div>
                            <div class="section-detail">
                                <ul class="list-item clearfix flex-product">
                                    <?php $__currentLoopData = $item_cat->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('product.detail', [$product->slug, $product->id])); ?>"
                                                title="" class="thumb">
                                                <img src="<?php echo e(url($product->img)); ?>">
                                            </a>
                                            <a href="?page=detail_product" title=""
                                                class="product-name"><?php echo e($product->name); ?></a>
                                            <div class="price">
                                                <span
                                                    class="new"><?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                                                <span class="old">21.990.000đ</span>
                                            </div>
                                            <div class="action clearfix">
                                                <a href="" data-id="<?php echo e($product->id); ?>"
                                                    class="add-cart fl-left add_product">Thêm giỏ hàng</a>
                                                <a href="<?php echo e(route('checkout_fast', $product->id)); ?>" title="Mua ngay"
                                                    class="buy-now fl-right">Mua ngay</a>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-danger">Không tồn tại danh mục và sản phẩm nào</p>
                <?php endif; ?>

            </div>
            <div class="sidebar fl-left">
                <div class="section" id="category-product-wp">
                    <div class="section-head">
                        <h3 class="section-title">Danh mục sản phẩm</h3>
                    </div>
                    <div class="secion-detail">
                        <?php echo $menu; ?>

                        
                    </div>
                </div>
                <div class="section" id="selling-wp">
                    <div class="section-head">
                        <h3 class="section-title">Sản phẩm bán chạy</h3>
                    </div>
                    <div class="section-detail">
                        <ul class="list-item">
                            <?php $__empty_1 = true; $__currentLoopData = $bestsellingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestsellingProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="clearfix">
                                    <a href="<?php echo e(route('product.detail', [$bestsellingProduct->slug, $bestsellingProduct->id])); ?>"
                                        title="" class="thumb fl-left">
                                        <img src="<?php echo e(url($bestsellingProduct->img)); ?>" alt="">
                                    </a>
                                    <div class="info fl-right">
                                        <a href="?page=detail_product" title=""
                                            class="product-name"><?php echo e($bestsellingProduct->name); ?></a>
                                        <div class="price">
                                            <span
                                                class="new"><?php echo e(number_format($bestsellingProduct->price, 0, ',', '.')); ?>đ</span>
                                            <span class="old">22.190.000đ</span>
                                        </div>
                                        <a href="<?php echo e(route('checkout_fast', $bestsellingProduct->id)); ?>" title=""
                                            class="buy-now">Mua ngay</a>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-danger">Không tồn tại sản phẩm bán chạy nào</p>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
                <div class="section" id="banner-wp">
                    <div class="section-detail">
                        <a href="" title="" class="thumb">
                            <img src="<?php echo e(asset('client.css/images/banner.png')); ?>" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/client/home.blade.php ENDPATH**/ ?>