
<?php $__env->startSection('content'); ?>
    <div class="success-message">
        <img id="icon-success" src="<?php echo e(asset('client.css/images/check.png')); ?>" alt="">
        <h1>Đặt hàng thành công!</h1>
        <p style="text-align:center">Cảm ơn bạn đã đặt hàng. Chúng tôi sẽ liên hệ với bạn sớm nhất!</p>
        <table class="shop-table">
            <thead>
                <tr class="detail-order">
                    <th>Ảnh</th>
                    <th>Sản phẩm</th>
                    <th>Tổng</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="cart-item">
                        <td><img src="<?php echo e(url($row->options->file)); ?>" alt=""></td>
                        <td><?php echo e($row->name); ?> <strong class="danger"> x <?php echo e($row->qty); ?></strong></td>
                        <td><?php echo e(number_format($row->price, 0, ',', '.')); ?>đ</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <td colspan="3"><span>Tổng giá tiền:</span> <strong><?php echo e(Cart::subtotal()); ?> Đ</strong></td>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/client/checkout/success.blade.php ENDPATH**/ ?>