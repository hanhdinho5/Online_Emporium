
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="checkout-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Thanh toán</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            <?php if(session('ok')): ?>
                <div class="alert alert-success"><?php echo e(session('ok')); ?></div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('confirm_checkout')); ?>" name="form-checkout">
                <?php echo csrf_field(); ?>
                <div class="section" id="customer-info-wp">
                    <div class="section-head">
                        <h1 class="section-title">Thông tin khách hàng</h1>
                    </div>
                    <div class="section-detail">
                        <div class="form-row clearfix">
                            <div class="form-col col-12 col-sm-6">
                                <label for="fullname">Họ tên</label>
                                <input type="text" name="fullname" id="fullname" value="<?php echo e(old('fullname')); ?>"
                                    class="form-control">
                                <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-col col-12 col-sm-6">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>"
                                    class="form-control">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-row clearfix">
                            <div class="form-col col-12 col-sm-6">
                                <label for="phone">Số điện thoại</label>
                                <input type="tel" name="phone" id="phone" value="<?php echo e(old('phone')); ?>"
                                    class="form-control">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-col col-12 col-sm-6">
                                <label for="province">Tỉnh/Thành phố:</label>
                                <select name="province" id="province" class="form-control">
                                    <option value="">---- Chọn tỉnh thành ----</option>
                                    <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->province_id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-row clearfix">
                            <div class="form-col col-12 col-sm-6">
                                <label for="district">Quận/Huyện</label>
                                <select name="district" id="district" class="form-control">
                                    <option value="" selected>---- Chọn Quận/Huyện ----</option>
                                    
                                </select>
                                <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-col col-12 col-sm-6">
                                <label for="commune">Xã/Thị trấn</label>
                                <select name="commune" id="commune" class="form-control">
                                    <option value="" selected>---- Chọn Xã/Thị trấn ----</option>
                                    
                                </select>
                                <?php $__errorArgs = ['commune'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-row clearfix">
                            <div class="form-col col-12">
                                <label for="address">Địa chỉ</label>
                                <input type="text" name="address" id="address" value="<?php echo e(old('address')); ?>"
                                    placeholder="Ngõ, thôn(bản)" class="form-control">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-col col-12">
                                <label for="notes">Ghi chú</label>
                                <textarea name="note" class="form-control" cols=""><?php echo e(old('note')); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section" id="order-review-wp">
                    <div class="section-head">
                        <h1 class="section-title">Thông tin đơn hàng</h1>
                    </div>
                    <div class="section-detail">
                        <table class="shop-table">
                            <thead>
                                <tr>
                                    <td>Sản phẩm</td>
                                    <td>Tổng</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="cart-item">
                                        <td class="product-name"><?php echo e($row->name); ?><strong
                                                class="product-quantity text-danger">x <?php echo e($row->qty); ?></strong>
                                        </td>
                                        <td class="product-total"><?php echo e(number_format($row->price, 0, ',', '.')); ?>đ</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>
                                <tr class="order-total">
                                    <td>Tổng đơn hàng:</td>
                                    <td><strong class="total-price"><?php echo e(Cart::subtotal()); ?>đ</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                        <div id="payment-checkout-wp">
                            <ul id="payment_methods">
                                <li>
                                    <input type="radio" id="direct-payment" name="payment-method"
                                        value="direct-payment">
                                    <label for="direct-payment">Thanh toán tại cửa hàng</label>
                                </li>
                                <li>
                                    <input type="radio" id="payment-home" name="payment-method" checked
                                        value="payment-home">
                                    <label for="payment-home">Thanh toán tại nhà</label>
                                </li>
                            </ul>
                        </div>
                        <div class="place-order-wp clearfix">
                            <input type="submit" id="order-now" value="Đặt hàng">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#province').on('change', function() {
                var province_id = $(this).val();

                // var selectedText = $('#province option:selected').text();   // Lấy text của option đang đc chọn
                // alert(selectedText);

                var data = {
                    province_id: province_id
                };
                $.ajax({
                    url: '<?php echo e(route('handle_ajax_district')); ?>',
                    method: 'POST',
                    data: data,
                    dataType: 'json',
                    success: function(data) {
                        // console.log(data);
                        $('#district').empty(); // gắn district empty
                        $.each(data, function(i, district) { // Duyệt district
                            $('#district').append($(
                                '<option>', { // Nối thêm option cho #district
                                    value: district.id,
                                    text: district.name,
                                }));
                        });

                        $('#commune').empty();

                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(xhr.status);
                        alert(thrownError);
                    }
                });
                // XỬ LÝ XÃ PHƯỜNG
                $('#district').on('change', function() {
                    var district_id = $(this).val();
                    if (district_id) {
                        $.ajax({
                            url: '<?php echo e(route('handle_ajax_wards')); ?>',
                            method: 'POST',
                            data: {
                                district_id: district_id
                            },
                            dataType: 'json',
                            success: function(data) {
                                // console.log(data);
                                $('#commune').empty();
                                $.each(data, function(i, wards) { // Duyệt wards
                                    $('#commune').append($(
                                        '<option>', { // Nối thêm option cho #wards (xã, phường)
                                            value: wards.id,
                                            text: wards.name,
                                        }));
                                });

                            },
                            error: function(xhr, ajaxOptions, thrownError) {
                                alert(xhr.status);
                                alert(thrownError);
                            }
                        });
                    } else
                        $('#commune').empty();
                });
            })

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/client/checkout/checkout.blade.php ENDPATH**/ ?>