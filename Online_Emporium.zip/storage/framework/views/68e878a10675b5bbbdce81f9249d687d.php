
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold">
            Chỉnh sửa thông tin quản trị viên
        </div>
        <div class="card-body">
            
            <?php echo Form::open(['route'=>['user.update', $user->id]]); ?>

                <?php echo csrf_field(); ?>
                <div class="form-group">
                    
                    <?php echo Form::label('name', 'Họ và tên'); ?>

                    <?php echo Form::text('name', $user->name, ['class' => 'form-control', 'id'=>'name']); ?>

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    
                    <?php echo Form::label('email', 'Email'); ?>

                    <?php echo Form::email('email', $user->email, ['class' => 'form-control', 'id'=>'email']); ?>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    
                    <?php echo Form::label('password', 'Mật khẩu'); ?>

                    <?php echo Form::password('password', ['class'=>'form-control', 'id'=>'password']); ?>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    
                    <?php echo Form::label('password-confirm', 'Xác nhận mật khẩu'); ?>

                    <?php echo Form::password('password_confirmation', ['class'=>'form-control', 'id'=>'password-confirm']); ?>

                </div>
                <div class="form-group">
                    
                    <?php echo Form::label('roles', 'Nhóm quyền (vai trò)'); ?>

                    <?php
                        $selectedRoles = $user->roles->pluck('id')->toArray();
                        $options = $roles->pluck('name', 'id')->toArray();  // id là value của options, name là gt hiển thị
                    ?>
                    <?php echo Form::select('roles[]', $options, $selectedRoles, ['class'=>'form-control', 'id'=>'roles', 'multiple'=>true]); ?>

                </div>

                <button type="submit" name="btn_update" class="btn btn-primary">Cập nhật</button>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>