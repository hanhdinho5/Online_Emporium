

<?php $__env->startSection('content'); ?>
    <div id="warpper-detail-order">
        <div class="row ">
            <div class="col-12">
                <h1 class="section-title text-center border-bottom py-2">Thông tin đơn hàng</h1>
            </div>
        </div>
        <?php if(session('ok')): ?>
            <div class="alert alert-success text-center"><?php echo e(session('ok')); ?></div>
        <?php endif; ?>
        <div class="contener ml-5 mt-3">
            <ul class="detail-order">
                <li>
                    <span class="bold mr-3">Tên khách hàng:</span> <?php echo e($detail_info->client); ?>

                </li>
                <li>
                    <span class="bold mr-3">Số điện thoại:</span> <?php echo e($detail_info->phone); ?>

                </li>
                <li>
                    <span class="bold mr-3">Địa chỉ:</span> <?php echo e($detail_info->address); ?>

                </li>
                <li>
                    <span class="bold mr-3">Email:</span> <?php echo e($detail_info->email); ?>

                </li>
                <li>
                    <form action="<?php echo e(route('update.status.order')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="status" class="bold">Trạng thái đơn hàng: </label>
                        <select name="status" id="status"  class="btn btn-info">
                            <option value="0" <?php echo e($status == '0'? 'selected': ''); ?>>Chờ xử lý</option>
                            <option value="1" <?php echo e($status == '1'? 'selected': ''); ?>>Giao hàng</option>
                            <option value="2" <?php echo e($status == '2'? 'selected': ''); ?>>Thành công</option>
                            <option value="3" <?php echo e($status == '3'? 'selected': ''); ?>>Đã huỷ</option>
                        </select>
                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                        <button type="submit" class="btn btn-primary">Cập nhật trạng thái</button>
                    </form>
                </li>
                <li class="mb-3">
                    <span class="bold">Sản phẩm:</span> 
                        <table class="shop-table border-bottom">
                            <thead>
                                <tr class="detail-order">
                                    <th>Ảnh</th>
                                    <th>Sản phẩm</th>
                                    <th>Tổng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detail_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="cart-item">
                                        <td class="pl-1 pr-1"><img style="width:120px; height:auto" src="<?php echo e(url($row->options->file)); ?>" alt=""></td>
                                        <td class="product-name pl-1 pr-1"><?php echo e($row->name); ?> <strong
                                                class="product-quantity text-danger pl-3 pr-5"> x <?php echo e($row->qty); ?></strong></td>
                                        <td class="product-total pl-1 pr-1"><?php echo e(number_format($row->price, 0, ',', '.')); ?> đ</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </li>
                <li>
                    <span class="bold">Số lượng:</span> <?php echo e($detail_info->quantity); ?> sản phẩm
                </li>
                <li>
                    <span class="bold">Tổng giá tiền:</span> <strong><?php echo e($detail_info->total_price); ?> Đ</strong>
                </li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>