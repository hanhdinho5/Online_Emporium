
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Thêm mới vai trò</h5>
                <div class="form-search form-inline">
                    <form action="#" class="d-flex">
                        <input type="" class="form-control form-search mr-1" placeholder="Tìm kiếm">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                
                <?php echo Form::open(['route' => 'role.store']); ?>


                <div class="form-group">
                    
                    <?php echo Form::label('name', 'Tên vai trò', ['class' => 'text-strong']); ?>

                    <?php echo Form::text('name', '', ['class' => 'form-control', 'id' => 'name']); ?>

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    
                    <?php echo Form::label('description', 'Mô tả', ['class' => 'text-strong']); ?>

                    <?php echo Form::textarea('description', '', ['class' => 'form-control', 'id' => 'description', 'rows'=>4]); ?>

                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <strong>Vai trò này có quyền gì?</strong>
                <small class="form-text text-muted pb-2">Check vào module hoặc các hành động bên dưới để chọn quyền.</small>
                <!-- List Permission  -->
                <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionName => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card my-4 border">
                        <div class="card-header">
                            
                            <?php echo Form::checkbox(null, null, null, ['class' => 'check-all', 'id' => $permissionName]); ?>

                            <?php echo html_entity_decode(
                                Form::label($permissionName, '<strong>' . 'Module ' . $permissionName . '</strong>', ['class' => 'm-0']),
                            ); ?>

                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        
                                        <?php echo Form::checkbox('permission_id[]', $item->id, null, ['class' => 'permission', 'id' => $item->slug]); ?>

                                        <?php echo Form::label($item->slug, $item->name); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Chưa tồn tại quyền nào trên hệ thống</p>
                <?php endif; ?>

                <input type="submit" name="btn-add" class="btn btn-primary" value="Thêm mới">
                
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $('.check-all').click(function() {
            $(this).closest('.card').find('.permission').prop('checked', this.checked)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/admin/role/add.blade.php ENDPATH**/ ?>