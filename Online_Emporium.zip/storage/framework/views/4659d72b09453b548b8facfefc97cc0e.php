
<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="clearfix blog-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Blog</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <div class="section" id="list-blog-wp">
                <div class="section-head clearfix">
                    <h3 class="section-title">Blog</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <li class="clearfix">
                            <a href="<?php echo e(route('page.detail')); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(asset('client.css/images/img-detail.jpg')); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="?page=detail_blog" title="" class="title">Mời gọi kiều bào hiến kế, chung sức xây dựng phát triển TP. Hồ Chí Minh</a>
                                <span class="create-date">28/11/2017</span>
                                <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham quan các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên phần mềm Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát Lái... để kiều bào hiểu thêm về tình hình phát [...]</p>
                            </div>
                        </li>
                        <li class="clearfix">
                            <a href="<?php echo e(route('page.detail')); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(asset('client.css/images/img-detail.jpg')); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="?page=detail_blog" title="" class="title">Mời gọi kiều bào hiến kế, chung sức xây dựng phát triển TP. Hồ Chí Minh</a>
                                <span class="create-date">28/11/2017</span>
                                <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham quan các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên phần mềm Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát Lái... để kiều bào hiểu thêm về tình hình phát [...]</p>
                            </div>
                        </li>
                        <li class="clearfix">
                            <a href="<?php echo e(route('page.detail')); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(asset('client.css/images/img-detail.jpg')); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="?page=detail_blog" title="" class="title">Mời gọi kiều bào hiến kế, chung sức xây dựng phát triển TP. Hồ Chí Minh</a>
                                <span class="create-date">28/11/2017</span>
                                <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham quan các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên phần mềm Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát Lái... để kiều bào hiểu thêm về tình hình phát [...]</p>
                            </div>
                        </li>
                        <li class="clearfix">
                            <a href="<?php echo e(route('page.detail')); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(asset('client.css/images/img-detail.jpg')); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="?page=detail_blog" title="" class="title">Mời gọi kiều bào hiến kế, chung sức xây dựng phát triển TP. Hồ Chí Minh</a>
                                <span class="create-date">28/11/2017</span>
                                <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham quan các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên phần mềm Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát Lái... để kiều bào hiểu thêm về tình hình phát [...]</p>
                            </div>
                        </li>
                        <li class="clearfix">
                            <a href="<?php echo e(route('page.detail')); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(asset('client.css/images/img-detail.jpg')); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="?page=detail_blog" title="" class="title">Mời gọi kiều bào hiến kế, chung sức xây dựng phát triển TP. Hồ Chí Minh</a>
                                <span class="create-date">28/11/2017</span>
                                <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham quan các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên phần mềm Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát Lái... để kiều bào hiểu thêm về tình hình phát [...]</p>
                            </div>
                        </li>
                        <li class="clearfix">
                            <a href="<?php echo e(route('page.detail')); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(asset('client.css/images/img-detail.jpg')); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="?page=detail_blog" title="" class="title">Mời gọi kiều bào hiến kế, chung sức xây dựng phát triển TP. Hồ Chí Minh</a>
                                <span class="create-date">28/11/2017</span>
                                <p class="desc">Trong ngày hôm nay (11/11) đoàn kiều bào đã tổ chức thành 4 nhóm đi tham quan các điểm như huyện Cần Giờ, Đại học Quốc gia, Khu công nghệ cao TP.HCM, Công viên phần mềm Quang Trung, Khu Nông nghiệp Công nghệ cao, Khu Đô thị mới Thủ Thiêm, Cảng Cát Lái... để kiều bào hiểu thêm về tình hình phát [...]</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="section" id="paging-wp">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="" title="">1</a>
                        </li>
                        <li>
                            <a href="" title="">2</a>
                        </li>
                        <li>
                            <a href="" title="">3</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="sidebar fl-left">
            <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm bán chạy</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__empty_1 = true; $__currentLoopData = $bestsellingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestsellingProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="clearfix">
                                <a href="<?php echo e(route('product.detail', $bestsellingProduct->id)); ?>" title="" class="thumb fl-left">
                                    <img src="<?php echo e(url($bestsellingProduct->img)); ?>" alt="">
                                </a>
                                <div class="info fl-right">
                                    <a href="?page=detail_product" title=""
                                        class="product-name"><?php echo e($bestsellingProduct->name); ?></a>
                                    <div class="price">
                                        <span
                                            class="new"><?php echo e(number_format($bestsellingProduct->price, 0, ',', '.')); ?>đ</span>
                                        <span class="old">22.190.000đ</span>
                                    </div>
                                    <a href="" title="" class="buy-now">Mua ngay</a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-danger">Không tồn tại sản phẩm bán chạy nào</p>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="?page=detail_blog_product" title="" class="thumb">
                        <img src="public/images/banner.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/client/page/page.blade.php ENDPATH**/ ?>