
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <?php if(session('ok')): ?>
            <div class="alert alert-success"><?php echo e(session('ok')); ?></div>
        <?php endif; ?>
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Chỉnh sửa thông tin quyền
                    </div>
                    <div class="card-body">
                        <?php echo Form::open(['route' => ['permission.update', $permission->id] ]); ?>

                        <div class="form-group">
                            <?php echo Form::label('name', 'Tên quyền'); ?>

                            <?php echo Form::text('name', $permission->name, ['class' => 'form-control', 'id' => 'name']); ?>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('slug', 'Slug'); ?>

                            <small class="form-text text-muted pb-2">Ví dụ: post.add</small>
                            <?php echo Form::text('slug', $permission->slug, ['class' => 'form-control', 'id' => 'slug']); ?>

                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('des', 'Mô tả'); ?>

                            <?php echo Form::textarea('des', $permission->description, ['class' => 'form-control', 'id' => 'des', 'rows' => 5]); ?>

                        </div>
                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách quyền
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên quyền</th>
                                    <th scope="col">Slug</th>
                                    <th scope="col">Tác vụ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $t = 0;
                                ?>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleName => $modulePermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"></td>
                                        <td><strong>Module <?php echo e(ucfirst($moduleName)); ?></strong></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php $__currentLoopData = $modulePermission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row"><?php echo e(++$t); ?></td>
                                            <td>|---<?php echo e($permission->name); ?></td>
                                            <td><?php echo e($permission->slug); ?></td>
                                            <td><a href="<?php echo e(route('permission.edit', $permission->id)); ?>"><button
                                                        class="btn btn-success btn-sm rounded-0" type="button"
                                                        data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                            class="fa fa-edit"></i></button></a>
                                                <a href="<?php echo e(route('permission.delete', $permission->id)); ?>"
                                                    onclick="return confirm('Bạn có chắc chắn muốn xoá trang này')"><button
                                                        class="btn btn-danger btn-sm rounded-0" type="button"
                                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                            class="fa fa-trash"></i></button></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/admin/permission/edit.blade.php ENDPATH**/ ?>