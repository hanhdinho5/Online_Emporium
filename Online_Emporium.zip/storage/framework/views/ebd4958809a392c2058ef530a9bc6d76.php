<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>demo</title>
</head>

<body>
    <h4>Samsung Galaxy A73 5G 128GB được xem là sản phẩm nổi bật nhất dòng Galaxy A 2022 mới ra mắt,
        máy trang bị bộ thông số kỹ thuật ấn tượng về phần hiệu năng, chất lượng màn hình và nổi bật nhất
        trong số đó là camera khi nó đem lại bức ảnh có độ phân giải lên đến 108 MP.</h4>
    <h4>Thỏa sức nhiếp ảnh với camera chụp ảnh sắc nét</h4>
    <p>Điều mà mình ấn tượng nhất trên Galaxy A73 5G đó chính là khả năng chụp ảnh khi máy sở hữu 4 ống kính có độ phân
        giải lần lượt: Camera chính 108 MP, camera góc siêu rộng 12 MP,
        cảm biến độ sâu và macro có cùng độ phân giải 5 MP giúp các bức ảnh thu lại trở nên chi tiết hơn.</p>
    <p>Chụp ảnh ở môi trường đủ sáng, ảnh do Galaxy A73 thu lại có độ chi tiết cao, màu sắc tươi tắn, ảnh sau khi zoom
        lên vẫn mang một chất lượng rất tốt bởi camera chính có độ phân giải cao, rất phù hợp với những ai thường dùng
        điện thoại để chụp ảnh.</p>
    <p>Còn về chế độ chụp chân dung cho dù là ngày hay đêm thì kết quả thu được đều làm mình bất ngờ, bởi máy mang đến
        bức ảnh trông rất nịnh mắt và có chiều sâu, độ chi tiết tốt, ranh giới giữa những vùng xóa phông và chủ thể được
        xử lý mịn màng.Hỗ trợ tính năng zoom 2x, 4x và 10x mang lại khả năng phóng to khung cảnh một cách nhanh chóng,
        giúp bạn quan sát đối tượng và bắt lại những khoảnh khắc đẹp chỉ trong tích tắc.</p>
</body>

</html>
<?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/demo.blade.php ENDPATH**/ ?>