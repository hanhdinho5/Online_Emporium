

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col">
                <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐANG XỬ LÝ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[0]); ?></h5>
                        <p class="card-text">Số lượng đơn hàng đang xử lý</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG THÀNH CÔNG</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[1]); ?></h5>
                        <p class="card-text">Đơn hàng giao dịch thành công</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                    <div class="card-header">DOANH SỐ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(number_format($total_revenue, 0, ',', '.')); ?> Đ</h5>
                        <p class="card-text">Doanh số hệ thống</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG HỦY</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[2]); ?></h5>
                        <p class="card-text">Số đơn bị hủy trong hệ thống</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end analytic  -->
        <div class="card">
            <div class="card-header font-weight-bold">
                ĐƠN HÀNG MỚI
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th scope="col">Mã</th>
                            <th scope="col">Khách hàng</th>
                            <th scope="col">Email</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Giá trị đơn hàng</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <?php if($orders_new->count() > 0): ?>
                        <tbody>
                            <?php
                                $t = 0;
                            ?>
                            <?php $__currentLoopData = $orders_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $t++;
                                ?>
                                <tr>
                                    <td><?php echo e($t); ?></td>
                                    <td><a href="<?php echo e(route('order.detail', $item->id)); ?>"><?php echo e($item->code); ?></a></td>
                                    <td>
                                        <?php echo e($item->client); ?><br>
                                        <?php echo e($item->phone); ?>

                                    </td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->total_price); ?> đ</td>
                                    <?php if($item->status == 0): ?>
                                        <td><span class="badge badge-warning">Chờ xử lý</span></td>
                                    <?php endif; ?>
                                    <?php if($item->status == 1): ?>
                                        <td><span class="badge badge-primary">Đang giao</span></td>
                                    <?php endif; ?>
                                    <?php if($item->status == 2): ?>
                                        <td><span class="badge badge-success">Hoàn thành</span></td>
                                    <?php endif; ?>
                                    <?php if($item->status == 3): ?>
                                        <td><span class="badge badge-danger">Đã huỷ</span></td>
                                    <?php endif; ?>

                                    <td><?php echo e($item->created_at); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['order.edit'])): ?>
                                            <a href="<?php echo e(route('order.edit', $item->id)); ?>"
                                                class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                data-toggle="tooltip" data-placement="top" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['order.delete'])): ?>
                                            <a href="<?php echo e(route('order.delete', $item->id)); ?>"
                                                onclick="return confirm('Bạn có chắc chắn muốn xoá đơn hàng')"
                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                    class="fa fa-trash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="9"><small>Click vào mã đơn hàng để xem chi tiết đơn hàng!</small></td>
                            </tr>
                        </tfoot>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="bg-white">Không tồn tại đơn hàng chờ xử lý nào</td>
                        </tr>
                    <?php endif; ?>
                </table>
                <?php echo e($orders_new->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>