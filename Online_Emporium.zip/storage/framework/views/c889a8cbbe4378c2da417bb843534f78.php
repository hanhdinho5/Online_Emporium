
<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="clearfix blog-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Blog</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <div class="section" id="list-blog-wp">
                <div class="section-head clearfix">
                    <h3 class="section-title">Blog</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="clearfix">
                                <a href="<?php echo e(route('post.detail', [Str::slug($post->name), $post->id])); ?>" title="" class="thumb fl-left">
                                    <img src="<?php echo e(url($post->img)); ?>" alt="">
                                </a>
                                <div class="info fl-right">
                                    <a href="<?php echo e(route('post.detail', [Str::slug($post->name), $post->id])); ?>" title="" class="title"><?php echo e($post->name); ?></a>
                                    <span class="create-date"><?php echo e($post->created_at); ?></span>
                                    <p class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ad, odio nisi excepturi eum, nostrum harum similique, perferendis tempore ipsum esse aliquam voluptate beatae non aut facilis deserunt. Dolorum, tenetur quos!</p>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-danger">Không tồn tại bài viết nào</p>
                        <?php endif; ?>
                        
                    </ul>
                </div>
            </div>
            <?php echo e($posts->links()); ?>

            
        </div>
        <div class="sidebar fl-left">
            <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm bán chạy</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__empty_1 = true; $__currentLoopData = $bestsellingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestsellingProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="clearfix">
                                <a href="<?php echo e(route('product.detail',[$bestsellingProduct->slug, $bestsellingProduct->id])); ?>" title="" class="thumb fl-left">
                                    <img src="<?php echo e(url($bestsellingProduct->img)); ?>" alt="">
                                </a>
                                <div class="info fl-right">
                                    <a href="?page=detail_product" title=""
                                        class="product-name"><?php echo e($bestsellingProduct->name); ?></a>
                                    <div class="price">
                                        <span
                                            class="new"><?php echo e(number_format($bestsellingProduct->price, 0, ',', '.')); ?>đ</span>
                                        <span class="old">22.190.000đ</span>
                                    </div>
                                    <a href="<?php echo e(route('product.detail',[$bestsellingProduct->slug, $bestsellingProduct->id])); ?>" title="" class="buy-now">Xem chi tiết</a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-danger">Không tồn tại sản phẩm bán chạy nào</p>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="?page=detail_blog_product" title="" class="thumb">
                        <img src="public/images/banner.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAM\htdocs\unitop.vn\LaravelPro\Online_Emporium\resources\views/client/post/post.blade.php ENDPATH**/ ?>